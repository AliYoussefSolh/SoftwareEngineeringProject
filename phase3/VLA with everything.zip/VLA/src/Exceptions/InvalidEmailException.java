package Exceptions;

@SuppressWarnings("serial")
public class InvalidEmailException extends Exception { }