package Exceptions;

@SuppressWarnings("serial")
public class InvalidFileFormatException extends Exception{ }
