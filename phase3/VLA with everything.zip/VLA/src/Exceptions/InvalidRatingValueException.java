package Exceptions;

@SuppressWarnings("serial")
public class InvalidRatingValueException extends Exception{}
