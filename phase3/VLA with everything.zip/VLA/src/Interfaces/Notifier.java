package Interfaces;

public interface Notifier {

	public void notifyUser();
	
}
