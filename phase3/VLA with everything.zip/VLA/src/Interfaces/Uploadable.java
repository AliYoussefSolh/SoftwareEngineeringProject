package Interfaces;

import java.io.IOException;

public interface Uploadable {
	
	public void uploadToDB() throws IOException;
	
}
